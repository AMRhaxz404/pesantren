<?php get_header(); ?>
    <div class="wm__looppost">
    	<div class="wm__container">
		    <div class="wm__404area">
			    <h1 class="wm__heading page_404"><?php wm_head_404(); ?></h1>
				<div class="wm__text text_404"><?php wm_text_404(); ?></div>
			</div>
		</div>
	</div>
<?php get_footer(); ?>