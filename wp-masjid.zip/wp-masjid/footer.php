            <div class="footer">
                <div class="wm__container">
	            	<div class="copyright">
<!-- 						<?php text_footer(); ?> -->
						Copyright © 2023 Yayasan Pondok Pesantren Mamba Unnur Wal Hidayah || <a href="www.linktr.ee/m_amriiin">IT AMRIN</a>
					</div>
				</div>
        	</div><!-- footer -->  
	    </div><!-- wrapper -->     	
		<div class="hidden_info"><?php hidden_info(); ?></div>
		<span class="toggle_info"><i class="icon-wm-maps"></i></span>
		<?php 
			wp_footer(); 
		?>
	</body>
</html>
