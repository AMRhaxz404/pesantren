<?php 
    get_header();
	get_template_part('wm-loop/rekening');
	get_template_part('wm-loop/pagination');
	get_footer();
