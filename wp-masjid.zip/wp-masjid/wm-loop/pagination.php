<div class="pagination">
    <div class="wm__container">
		<?php previous_posts_link(__('<i class="icon-wm-left"></i>', 'masjid')); ?>
		<?php wm_numeric_pagination(); ?>
		<?php next_posts_link(__('<i class="icon-wm-right"></i>', 'masjid')); ?>
	</div>
</div>