<?php 
    get_header();
	get_template_part('wm-loop/bulan');
	get_template_part('wm-loop/pagination');
	get_footer();
