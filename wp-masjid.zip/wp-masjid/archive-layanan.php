<?php 
    get_header();
	get_template_part('wm-loop/layanan');
	get_template_part('wm-loop/pagination');
	get_footer();
