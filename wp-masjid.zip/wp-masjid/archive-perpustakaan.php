<?php 
    get_header();
	get_template_part('wm-loop/library');
	get_template_part('wm-loop/pagination');
	get_footer();
